const express = require('express');
var app = express();
var session = require('express-session');
app.use(session({resave: true, secret: 'nbad03', saveUninitialized: true}));

var bodyParser = require('body-parser');
let giftController = require('./controllers/giftController');
var profileController = require('./controllers/profileController');
app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

//const path = require('path');
//app.use(express.static(path.join(__dirname, 'assets')));
var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.use(urlencodedParser);

app.use('/', giftController);
app.use('/myitems', profileController);
app.use('/Categories',giftController);
app.use('/Categories/item/:itemCode',giftController);
app.use('/contact', giftController);
app.use('/about', giftController);
//app.use('/signOut', giftController);
app.use('/signOut', profileController);
app.use('/feedback/:itemCode',profileController);
app.use('/signIn',giftController);


app.listen(8080,function(){
    console.log('app started')
    console.log('listening on port 8080')
});

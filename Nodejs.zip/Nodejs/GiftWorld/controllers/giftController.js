var express = require('express');
var router = express.Router();
var itemdb = require('../utility/itemdb');
var schema = require('../utility/schema');
var catname='';
var itemcodeexists=0;
var welcomeUser;
var UserDB= require('../utility/UserDB');
var UserProfile = require('../models/UserProfile');
var UserItem = require('../models/UserItem');
var User=require('../models/User');
 var Promise = require('promise');
 var Item = require('../models/item');
 var categories=[];
 var itemCode;

router.get('/', function(req, res) {
  if(req.session.theUser)
	{
    var user=req.session.theUser;
		welcomeUser = "Welcome "+user[0].firstName;
	}
  else
  {
	welcomeUser = "Not Signed In";
  }
  var data = { userName: welcomeUser };
  res.render('index',{data:data});
});

//signout
router.get('/Categories', function(req, res) {

  if(req.session.theUser)
	{
    var user=req.session.theUser;
		welcomeUser = "Welcome "+user[0].firstName;
	}
  else
  {
	welcomeUser = "Not Signed In";
  }
  //var data = { userName: welcomeUser };
  if(Object.keys(req.query).length === 0)
  {
    console.log('query lenght is zero'+Object.keys(req.query).length)
  var   categoryname='';
  //var categories = itemdb.getCategories();
 var initializePromise = promise1;
  initializePromise.then(function(result)
  {
  //var itemData = itemdb.getItems();
  console.log('after executing promise');
  console.log("cat lenght in controll"+result);
  var data= {
    categoryName: categoryname,
      categories: result,
       userName: welcomeUser

  }
  console.log("cat lenght in controll"+result.length);
  res.render('Categories', { data: data});
});
}
else
 {
   var itemdatabycat;
   var categories;
  var categoryname =req.query.Category;
  catname=categoryname;
  console.log('catname'+catname);
  var initializePromise = promise1;
   initializePromise.then(function(result1)
   {
     categories=result1;
     var itemsbycat=[];
     var itemData = itemdb.getItems();
		itemData = itemData.exec();
    itemData.then(function(docs){
      docs.forEach(function (item) {
          if(item.catalogCategory==catname){
              itemsbycat.push(item);
          }

      });
      var data= {
      categories:categories,
      categoryName: categoryname,
      items: itemsbycat,
      userName: welcomeUser
  }

  res.render('Categories', { data: data});
  });
  });



  //res.send("hello"+catname);
}

});


router.get('/contact', function(req, res) {
  if(req.session.theUser)
	{
    var user=req.session.theUser;
		welcomeUser = "Welcome "+user[0].firstName;
	}
  else
  {
	welcomeUser = "Not Signed In";
  }
    var data = { userName: welcomeUser };
  res.render('contact',{data:data});
});

router.get('/about', function(req, res) {
  if(req.session.theUser)
	{
    var user=req.session.theUser;
		welcomeUser = "Welcome "+user[0].firstName;
	}
  else
  {
	welcomeUser = "Not Signed In";
  }
  console.log('message in about'+welcomeUser);
    var data = { userName: welcomeUser };
  res.render('about',{data:data});
});


router.get('/Categories/item/:itemCode',function(req, res) {
  var exists=false;
  if(req.session.theUser)
	{
    var user=req.session.theUser;
		welcomeUser = "Welcome "+user[0].firstName;
	}
  else
  {
	welcomeUser = "Not Signed In";
  }
   itemCode = req.params.itemCode;
    //  var exists=checkitemcode(itemCode);

    var item = itemdb.getItem(itemCode);
    item = item.exec();
    item.then(function(doc){

      if(doc.length)
      {
      console.log('item here'+doc);

        var data= {
        item: doc,
        userName: welcomeUser,
        message:""}
      res.render('item', { data: data});
    }
      else
      {
        console.log('invalid itemcode');
        res.redirect('/Categories');
      }
    });




});


let getCategories = function() {
    // get the category of each item
    //let itemdata=[];
   //var itemdata = itemdb.getItems();
categories=itemdb.getCategories();

    return categories;
};

var checkitemcode=new Promise(function(resolve,reject)
{
  var exists=false;

  var itemData = itemdb.getItems();
  itemData = itemData.exec();
  itemData.then(function(docs){
    docs.forEach(function (item) {
        if(itemCode==item.itemCode){
          exists=true;
          resolve(exists);
          console.log("item code "+ exists);
        }

    });

  });

});

//sign in
router.get('/signIn',function(req, res){

  //check the user session
  console.log("sign in here -- ");
    if(!req.session.theUser)
    {
      console.log('came to sign in');
      var user;
      var userData= UserDB.getUsers();
      userData = userData.exec();
      userData.then(function(doc)
      {
        req.session.theUser=doc;
         user=req.session.theUser;
        console.log('sandhya User id in session '+user[0].userId);

        var useritems=UserProfile.getUserItems(user[0].userId);
        useritems=useritems.exec();
        useritems.then(function(docs){
        var useritemList=docs;
        var profile=new UserProfile(user[0].userId,docs);
        req.session.userProfile=profile;
        welcomeUser="Welcome"+user[0].firstName;
        console.log('welcome user'+welcomeUser);
        var data = {
          userItems: useritemList,
          userName: welcomeUser
            };
            res.render('myItems', {data: data});

        });
      });


    }
    else
    { console.log('session exist with user: '+req.session.theUser.firstName);
      welcomeUser="Welcome "+req.session.theUser.firstName;
    }
    //end check user session
			res.redirect('/myItems');

});


var promise1 = new Promise(function(resolve, reject) {
  var prom2=itemdb.getCategories;

  prom2.then(function(result)
{
  console.log('newlog'+result);
  resolve(result);

});

});


var itemsbycat = [];

var promise2 = new Promise(function(resolve,reject) {

    var itemsbycat=[];
    console.log('---you are here in itemscate promise');
    var promisecat= itemdb.getItems;
    promisecat.then(function(result)
    {
    console.log('items in cat call'+result.length);
    console.log('cat nem here'+catname);
    result.forEach(function (item) {
        if(item.catalogCategory==catname){
            itemsbycat.push(item);
        }

    }
  );
  console.log('itemsbycat length :'+itemsbycat)
  resolve(itemsbycat);
});

    //return itemsbycat;
});

module.exports = router;

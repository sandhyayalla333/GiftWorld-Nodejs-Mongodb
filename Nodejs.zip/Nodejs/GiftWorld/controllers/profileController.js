var express = require('express');
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var router = express.Router();

var itemdb = require('../utility/itemdb');
var UserDB= require('../utility/UserDB');
var UserProfile = require('../models/UserProfile');
var UserItem = require('../models/UserItem');
var User=require('../models/User');
var welcomeUser='Not Signed In';
router.get('/', urlencodedParser, function(req, res) {
var action=req.query.action;
var userSession=req.session.theUser;
if(userSession==undefined)
{
  if( action==undefined)
  {
    console.log('nosession and no action logic');
    var user;
    var userData= UserDB.getUsers();
    userData = userData.exec();
    userData.then(function(doc)
    {
      req.session.theUser=doc;
       user=req.session.theUser;
      console.log('sandhya User id in session '+user[0].userId);

      var useritems=UserProfile.getUserItems(user[0].userId);
      useritems=useritems.exec();
      useritems.then(function(docs){
      var useritemList=docs;
      console.log('useritemslength'+useritemList.length);

      var profile=new UserProfile(user[0].userId,docs);
      req.session.userProfile=profile;
      welcomeUser="Welcome"+user[0].firstName;
      console.log('welcome user'+welcomeUser);
      var data = {
        userItems: useritemList,
        userName: welcomeUser
          };
          res.render('myItems', {data: data});

      });
    });


  }
  //undefined action ended there
  //action save
  else if(action=='save'){

    welcomeUser='Not Signed In'
    console.log('Save Action  Called');
   var itemCode=req.query.itemList;
   console.log("itemcode to save when no sesion", itemCode);
   var allItems=itemdb.getItem(itemCode);
   item=allItems.exec();
    item.then(function(doc) {
      console.log("itemcode found ", doc);
      var data= {
      item: doc,
      userName: welcomeUser,
      message:"Please click Sign in before Saving ."}
    res.render('item', { data: data});
    });
  }
  //action save end here
  //action rate it
  else if(action=='updateProfile'){
  welcomeUser='Not Signed In';
      console.log('Rate Action is Called');
      var itemCode=req.query.itemList;
      var allItems=itemdb.getItem(itemCode);
      item=allItems.exec();
      item.then(function(docs){

        var data= {
        item: docs,
        userName: welcomeUser,
        message:"Please click Sign in before Rate ."}
      res.render('item', { data: data});

       });
    }
  //end action rate it
}
//if user exists
else
{
  var user=req.session.theUser;
  var userId=user[0].userId;
  welcomeUser='Welcome '+user[0].firstName;
  if(action=='deleteItem')
  {
    console.log("entered delete")
    itemCode=req.query.itemList;
    var stored=0;

    console.log('userid from session in delete'+userId);
    var allItems=UserProfile.getUserItems(userId);
    var present=0;
    allItems.exec().then(function(docs){
      for(i=0;i<docs.length;i++){
        if(docs[i].itemCode==itemCode){
          present=1;
    }
  }
  if(present==1)
  {
    console.log('item is present')
      UserProfile.removeItem(userId,itemCode);
      console.log('after deletion');
      setTimeout(function(){
      var allItems=UserProfile.getUserItems(userId);
      allItems.exec().then(function(doc){
        console.log(doc.length ,'are the remaining elements')

        if(doc.length!=0)
        {
          console.log('data after delettion' +doc);
          var data = {
            userItems: doc,
            userName: welcomeUser
              };
              res.render('myItems', {data: data});
      }
      else {
        var data = {
          userItems: [],
          userName: welcomeUser
            };
            res.render('myItems', {data: data});
      }
    });},100);

  }
  else{
      console.log('item is not present');

  }

});




}// for delete end

//sessio exist and no Action
else if(action==undefined){


  var allItems=UserProfile.getUserItems(userId);
  allItems.exec().then(function(docs){
    if(docs.length!=0){
      var data = {
        userItems: docs,
        userName: welcomeUser
      };
      console.log('useritems in my items'+docs);
      res.render('myItems', {data: data});
}
else{

  var data = {
    userItems: [],
    userName: welcomeUser
  };
  res.render('myItems', {data: data});
}
});
}//action undefined end

//save function if session exists
else if(action=='save'){

var itemCode=req.query.itemList;
var stored=0;
var allItems=UserProfile.getUserItems(userId);
allItems.exec().then(function(docs){
  for(i=0;i<docs.length;i++){
    if(docs[i].itemCode==itemCode){
      stored=1;
    }
  }
if(stored==0){
  console.log('entered');
  UserProfile.addItem(userId,itemCode);
}
if(stored==1){
  console.log('Gift is already saved!');
}
});

setTimeout(function(){var totalData=UserProfile.getUserItems(userId);
totalData.exec().then(function(docs){

  var data = {
    userItems: docs,
    userName: welcomeUser
  };
  res.render('myItems', {data: data});

});} ,200);


}//end of saved
//start of save
else if(action=='updateProfile')
{
var itemCode=req.query.itemList;
var item=itemdb.getItem(itemCode).exec().then(function(docs){

if(docs.length!=0){

    var useritem=UserProfile.getuserItem(userId,itemCode);
    useritem.exec().then(function(item)
  {
if(item.length!=0)
{
    var finalFlag='';

    if(item[0].madeit==="YES")
    {
      finalFlag = 'checked';
    }
    if(item[0].madeit==="NO")
    {
      finalFlag = '';
    }
    console.log('madeit box has to be from database'+item[0].madeit);
    console.log('madeit box has to be'+finalFlag);

    var data = {
      theItem: docs,
      selectedRating: item[0].rating,
      checkboxFlag: finalFlag,
      userName: welcomeUser
    };

      res.render('feedback', { data: data });
}
else {
    var data= {
      item: docs,
      userName: welcomeUser,
  message:"Please save before rate it"}
res.render('item', { data: data});

  }
  });

}
else {

     var data = {
       theItem: [],
       selectedRating: "0",
       checkboxFlag: finalFlag,
       userName: welcomeUser
         };
         res.render('feedback', { data: data });

}

});
}//end of update
//update rating
else if(action=='updateRating'){
 var currentRating = req.query.UserRating;
 var itemCode=req.query.itemList;
  UserProfile.updateItemRating(userId,itemCode,currentRating);
  setTimeout(function(){
  var items=UserProfile.getUserItems(userId)
    items.exec().then(function(docs){
      console.log(docs,'is the updated data')
      if(docs.length!=0){
        var data = {
          userItems: docs,
          userName: welcomeUser
        };
        res.render('myItems', {data: data});
      }
      else{
        var data = {
          userItems: [],
          userName: welcomeUser
        };
        res.render('myItems', {data: data});
      }
    });},200);

}//end of update rating
//update flag
else if(action=='updateFlag'){
  var itemCode=req.query.itemList;
    var flagexists = false;
  var allQueries = Object.keys(req.query);
     var arr = JSON.stringify(allQueries).split(",");
        for(var i=0; i<arr.length; i++)
           {
                 if(arr[i] == "flag")
                     {
                            flagexists = true;
                     }
             }
             console.log("flag value"+flagexists);
               var newFlag = req.query.flag;
               console.log("flag new "+newFlag);

       if(newFlag=="on" || !flagexists)
       {
         var actualflag;
         if(newFlag=="on")
         {
           actualflag="YES";
         }
         else if( !flagexists)
          {
           actualflag="NO";
         }

    UserProfile.updateItemMadeIt(userId,itemCode,actualflag);

    setTimeout(function(){
    var items=UserProfile.getUserItems(userId)
    items.exec().then(function(docs){
      if(docs.length!=0){
        var data = {
          userItems: docs,
          userName: welcomeUser
        };
        res.render('myItems', {data: data});
      }
      else{
        var data = {
          userItems: [],
          userName: welcomeUser
        };
        res.render('myItems', {data: data});
      }
    });
    },200);
}
}
//end of update flag
//end of session
}
//end of if user exist

});
//old code
/////////////////


//old ccode
let checkitemcode=function(itemCode)
{
  var exists=false;
  var data = itemdb.getItems();
  data.forEach(function (item) {
      if(itemCode==item.itemCode){
        exists=true;
      }
  });
  return exists;
};

router.get('/feedback/:itemCode', function(req, res) {
  var itemCode = req.params.itemCode;
var exists=checkitemcode(itemCode);
if(exists)
{
  var item = itemdb.getItem(itemCode);
  var newUsrItem = new UserItem(
      item,
      0,
      false
      );


  var data = {
        theItem: newUsrItem,
        selectedRating: '1',
        checkboxFlag: "checked",
        userName: welcomeUser
      };


    res.render('feedback', { data: data});
  }
  else {
    res.redirect('/Categories');
  }
  //res.render('feedback');
});

var signOutAction = function (req, res) {
	req.session.destroy();

	res.render('index');
};

//sign in
router.get('/signIn', urlencodedParser,function(req, res){

  //check the user session
  console.log("sign in here -- ");
    if(!req.session.theUser){

     var newUser = new User();
    var usersList = UserDB.getUsers();
      usersList=usersList.exec();
      usersList.then(function(doc){

     doc.forEach(function (k) {
     newUser = new User(
       k.userId,
       k.firstName,
       k.lastName,
       k.email,
       k.address1,
       k.address2,
       k.city,
       k.state,
       k.zip,
       k.country
     );
     req.session.theUser = newUser;
     welcomeUser="Welcome "+req.session.theUser.firstName;
     console.log('sessiondata stored'+req.session.theUser.firstName);

     });

   });

    }
    else
    { console.log('session exist with user: '+req.session.theUser.firstName);
      welcomeUser="Welcome "+req.session.theUser.firstName;
    }
    //end check user session
			res.redirect('/myItems');

});

//end sign in
//signout
router.get('/signOut', function(req, res){
  console.log('signout in profile');
	if (req.session) {
    req.session.destroy(function(err) {
      if(err) {
        return next(err);
      } else {
		  console.log('deleted');
        return res.redirect('/');
      }
    });
  }
});


module.exports=router;


class UserItem   {

/**
     * Constructor
     * @param item
     * @param rating
     * @param madeit
		  * @param userId
*/

	constructor(item,rating,madeit){
  //  super();
		this.item = item;
		this.rating = rating;
		this.madeit = madeit;

	}

}

module.exports = UserItem;

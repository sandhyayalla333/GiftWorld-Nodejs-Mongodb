var UserItem = require('./UserItem');
var UserDB = require('../utility/UserDB');
var  schema= require('../utility/schema');
var itemdb = require('../utility/itemdb');
var updatedlist = [];

class UserProfile {

/**
     * Constructor
     * @param userId
     * @param userItems

*/

	constructor(userId, userItems){

		this.userId = userId;
		this.userItems = userItems;

	}



  //save item
    saveitem(currentList, userItem){
        updatedlist = currentList;

        var exist=0;
	       for(var i=0; i<updatedlist.length;i++)
         {
		         if(updatedlist[i].item.itemCode ===userItem.item.itemCode)
             {
			            exist=1;
		         }
	       }
         if(exist===0)
         {
           updatedlist.push(userItem);
         }
         return updatedlist;
    };

  //end -save item
  //remove item
  removeUserItem(useritems,item) {
  	var tempUserItems = useritems;
  	for(var i=0; i<tempUserItems.length;i++){
  		if(tempUserItems[i].item.itemCode === item.item.itemCode){
  			tempUserItems.splice(i, 1);
  		}
  	}
  	return tempUserItems;
  };
  //end remove item


  //update userItem
  updateUserItem(useritems,item) {
  	var tempUserItems = useritems;
  	for(var i=0; i<tempUserItems.length;i++){
  		if(tempUserItems[i].item.itemCode === item.item.itemCode){
  			tempUserItems[i].madeit=item.madeit;
        tempUserItems[i].rating=item.rating;
  		}
  	}
  	return tempUserItems;
  };
  //end update user item
  //update rating
  updateItemRating(userList, userItem, newRating, position){

    console.log(" ---user prof rating");
			var initialRating = userItem.rating;

					if(newRating == 0)
					{
						userItem.rating = 0;
					}
					else if(initialRating == newRating)
					{
						console.log('No update in the rating');
					}
					else if(initialRating != newRating)
					{
						userItem.rating = newRating;
            console.log("updating rating for user"+ userItem.rating);
					}
					userList[position] = userItem;

					return userList;

	}

  //end update rating
  //update madeit
  updateItemmadeFlag(userList, userItem, newFlag, position){

  		console.log('update flag in up for  updteitem: '+userItem.item.itemName+ ' ini rat= '+userItem.madeit);
  			var initialFlag = userItem.madeit;

  					if(initialFlag === newFlag)
  					{
  						console.log('both flags are same');
  					}
  					else if(initialFlag !== newFlag)
  					{
  						console.log('both ratings are not same');
  						userItem.madeit = newFlag;
  					}

  					userList[position] = userItem;
            console.log("new value in userlist madeit"+ userList[position].madeit);

  					return userList;

  	}
  //end update madeit


  //get useritems
  getItems(userID){

		var updatedlist = UserDB.getUserProfileList();

		var userArrList;
			if(updatedlist.userId== userID){
				userArrList= updatedlist.userItems;
			}
      for(var i=0; i<userArrList.length;i++){
        	console.log('rating of the items are  '+userArrList[i].rating);
      }
		//}
		console.log('getitems arr len= '+userArrList.length);
		return userArrList;

	}
	emptyProfile(){
	ulist = UserDB.getUserProfileList();
		ulist=[];
		return ulist;
	}
//end get useritems
}

//mongodb new methods

var getUserItems=function(userid){
  console.log(userid,'is   passed')
  var userData=schema.userItemsData.find({userId:userid});

  userData.exec().then(function(docs){
     console.log(docs,'is in userprofile')
  });

  return userData;
}

//to save the items
var addItem=function(userId,itemCode){
  var item=itemdb.getItem(itemCode);
  item=item.exec();
  item.then(function(docs){
    var newUserItem=new schema.userItemsData({
      itemCode:itemCode,
      itemName: docs[0].itemName,
      catalogCategory:docs[0].catalogCategory,
      rating: "0",
      madeit: "NO",
			userId: userId,
    });
    newUserItem.save().then(function(docs){
      console.log('item is saved successfully')
    })

});
}

//to remove item
var removeItem=function(userId,itemCode){

  schema.userItemsData.remove({userId: userId,itemCode:itemCode}).then(function(docs){
    console.log(docs.length);
  });

}
//to update rating
var updateItemRating=function(userId,itemCode,rating){

schema.userItemsData.update({userId:userId,itemCode:itemCode},{$set:{rating:rating}}).exec().then(function(docs){
  console.log('updating the rating')
});

}

//to update madedit
var updateItemMadeIt=function(userId,itemCode,madeIt){

schema.userItemsData.update({userId:userId,itemCode:itemCode},{$set:{madeit:madeIt}}).exec().then(function(docs){
  console.log('updating the madeit')
});

}

var getuserItem = function(userId,itemCode){
 var useritem=schema.userItemsData.find({userId: userId,itemCode:itemCode});
return useritem;
};

module.exports = UserProfile;
module.exports.getUserItems=getUserItems;
module.exports.removeItem=removeItem;
module.exports.updateItemRating=updateItemRating;
module.exports.updateItemMadeIt=updateItemMadeIt;
module.exports.addItem=addItem;
module.exports.getuserItem=getuserItem;

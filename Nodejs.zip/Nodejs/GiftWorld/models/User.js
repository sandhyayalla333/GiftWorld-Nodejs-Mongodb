class User{

/**
     * Constructor
     * @param userID
     * @param firstName
     * @param lastName
	 * @param email
	 * @param address1
     * @param address2
	 * @param city
	 * @param state
	 * @param zip
			* @param country

     */


constructor(userID, firstName, lastname, email, address1, address2, city, state, zip, country){
	this.userID = userID;
	this.firstName = firstName;
	this.lastname = lastname;
	this.email = email;
	this.address1 = address1;
	this.address2 = address2;
	this.city = city;
	this.state = state;
	this.zip = zip;
	this.country = country;
}}

module.exports = User;

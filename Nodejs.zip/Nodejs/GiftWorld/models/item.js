

class Item {

    /**
     * Constructor
     * @param itemCode
     * @param itemName
     * @param catalogCategory
     * @param description
     * @param rating
     * @param imageURL
     * @param userId
     */
    constructor(itemCode, itemName, catalogCategory,note, description, rating, imageURL,userId) {
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.catalogCategory = catalogCategory;
        this.note = note;
        this.description = description;
        this.rating = rating;
        this.imageURL = imageURL;
        this.userId=userId;
    }
    getImageURL(itemCode){
      console.log("image url "+ '/assets/images/' + itemCode + '.jpg')
			return  '/assets/images/' + itemCode + '.jpg';

			//console.log('img path: '+path);
		}




}

module.exports = Item;

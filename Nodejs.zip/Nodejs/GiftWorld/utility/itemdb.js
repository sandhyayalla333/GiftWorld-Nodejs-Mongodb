var Item = require('../models/item');
var  schema= require('./schema');
var Promise=require('promise');
var itemObj = new Item();


//module.exports.getItems = function () {
  let getItemspro = new Promise(function (resolve,reject) {

    console.log("get items call here");
    schema.itemData.find().then(function(doc)
    {
      var items=[];
      doc.forEach(function(data){

       let item=new Item(data.itemCode,
           data.itemName,
           data.catalogCategory,
           data.note,
           data.description,
           data.rating,
           data.imgUrl,
           data.userId
       );
       items.push(item);
 });
      console.log("data from mongo"+doc.length);
      console.log("data legth in resolve"+items.length);
    //return doc;
    resolve(items);
  });
    // return data;
});

/**
 *
 * @param itemCode
 * @returns {*}
 */
let getItem1 = function (itemCode) {

  schema.itemData.find({itemCode:itemCode},function(err,data)
{

if(data.length)
{
  console.log("mongodb ,item code found with legnth : "+ data.length);
  let item = new Item(data.itemCode,
      data.itemName,
      data.catalogCategory,
      data.note,
      data.description,
      data.rating,
      data.imgUrl,
      data.userId
    );
    return item;
}
});


};


let getCategories1 = function() {
    var categories=[];
       var items=getItems();
       if(items!=null)
       {
         console.log('lsit of item in cat call'+items.length);
         items.then(function(result)
     {
       console.log('lsit of item in cat call'+result.length);
     });
   }


    return categories;
};


let getCategories2=function()
{
  var categories=[];
  schema.itemData.find().then(function(doc)
  {
    doc.forEach(function (item) {
        if(!categories.includes(item.catalogCategory)){
            categories.push(item.catalogCategory);
          }
          console.log("cat items "+categories.length);

    });
    return categories;
  });
}
let getCategories=new Promise(function(resolve,reject)
{
  var categories=[];
  schema.itemData.find().then(function(doc)
  {
    doc.forEach(function (item) {
        if(!categories.includes(item.catalogCategory)){
            categories.push(item.catalogCategory);
          }
          console.log("cat items "+categories.length);

    });
    resolve(categories);
  });
});
//new methods
var getItems = function(){
  var data = schema.itemData.find();
  console.log('getitems func lenght'+ data.length);
  return data;
}

var getItem = function(code){
var item = schema.itemData.find({itemCode:code});
return item;
};



var category = ["Birthday", "HouseWarming","KidsFav"];
module.exports={
  getItemspro:getItemspro,
  getItems:getItems,
  getItem:getItem,
  getCategories:getCategories
};

var item = require('../models/item');
var itemdb = require('./itemdb');
var User = require('../models/User');
var UserProfile = require('../models/UserProfile');
var UserItem = require('../models/UserItem');
var  schema= require('./schema');

var itemData = itemdb.getItems;

//hard-coded users

var users = [
	{
  userId:"100",
  firstName:"Naga",
  lastName:"yalla",
  emailAddress:"sandhyayalla333@gmail.com",
  addressField1:"8825 Camden",
  addressField2:"apt103",
  city:"Charlotte",
  state:"NC",
  postCode:"28273",
  country:"U.S.A"

	}
]
//end hard-coded users

//hard coded -userItems
var userItems = [
	{
		item: itemdb.getItem(1),
		rating: 0,
		madeit: false

	},
  {
		item: itemdb.getItem(2),
		rating: 0,
		madeit: false

	},
  {
		item: itemdb.getItem(3),
		rating: 0,
		madeit: false

	},

  {
		item: itemdb.getItem(6),
		rating: 0,
		madeit: false

	}

]
//end hard coded-userItems

//get user profiles

module.exports.getUserProfileList = function(){


	//var userProfList = [];
	var userItems1=[];
    for (var i = 0; i < userItems.length; i++) {
		var usrItem = new UserItem(
			userItems[i].item,
			userItems[i].rating,
			userItems[i].madeit
		);

		userItems1.push(usrItem);

    }
    var UserProfile = require('../models/UserProfile');
		var usrProfile = new UserProfile(
			'100',
			userItems1
		);
		console.log('userdb getprofitems len= '+usrProfile.userItems.length);
    return usrProfile;

};
//end -get user profiles

//get user

module.exports.getUsers= function () {
  let userlist = [];
  for (let i = 0; i < users.length; i++)
  {
      let user = new User(users[i].userId,
          users[i].firstName,
          users[i].lastName,
          users[i].emailAddress,
          users[i].addressField1,
          users[i].addressField2,
          users[i].city,
          users[i].state,
          users[i].postCode,
          users[i].country);

      userlist.push(user);
    }
  return userlist;
};
//end get user

//get useritemlist

// end getuser item list


// new methods for mongodb

var item = require('../models/item');
var itemdb = require('./itemdb');
var User = require('../models/User');
var UserProfile = require('../models/UserProfile');
var UserItem = require('../models/UserItem');
var  schema= require('./schema');

module.exports.getUsers= function () {

  var data = schema.userData.find();
  console.log('getusers func lenght');
  return data;

};


module.exports.getUserProfileList = function(userId){

	var userItems1=[];
    var UserProfile = require('../models/UserProfile');
		var usrProfile = new UserProfile(
			userId,
			userItems1
		);
		console.log('userdb getprofitems len= '+usrProfile.userItems.length);
    return usrProfile;

};

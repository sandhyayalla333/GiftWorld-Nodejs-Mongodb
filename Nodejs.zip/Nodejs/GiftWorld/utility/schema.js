var mongoose=require('mongoose');


mongoose.connect('mongodb://localhost/GiftShop');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log("we're connected!");
});
var Schema=mongoose.Schema;
var itemschema=new Schema({
  itemCode:{type:Number,required:true},
  itemName:String,
  catalogCategory:String,
  note:String,
  description:String,
  rating:Number,
  imgUrl:String,
  userId:Number
},{collection:'Item'});
var itemData=mongoose.model('itemData',itemschema);

var Schema1=mongoose.Schema;
var userSchema=new Schema1({
  userId:{type:Number,required:true},
  firstName:String,
  lastName:String,
  password:String,
  emailAddress:String,
  addressField1:String,
  addressField2:Number,
  city:String ,
  state:String,
  postCode:String,
  country:String
},{collection:'User'});

var userData=mongoose.model('userData',userSchema);

var Schema2=mongoose.Schema;
var userItemSchema=new Schema2({
  itemCode:{type:Number},
  itemName: String,
  catalogCategory:String,
  rating:String,
  madeit:String,
  userId:Number
},{collection:'UserItem'});
var userItemsData=mongoose.model('userItems',userItemSchema);


module.exports={

    itemData  :itemData,
      userData:userData,
      userItemsData:userItemsData

  };
